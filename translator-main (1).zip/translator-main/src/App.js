import Translate from "./component/Translate";
import "./App.css";

function App() {
  return (
    <>
      <Translate />
    </>
  );
}

export default App;
